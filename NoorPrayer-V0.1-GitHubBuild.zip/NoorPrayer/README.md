# NoorPrayer V0.1
Android/Kotlin prototype for a silent flashlight alarm.

## Open
1. Open Android Studio.
2. Choose **Open** and select the `NoorPrayer` folder.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging and press Run.
5. Grant Camera permission and "Alarms & reminders" access.
6. Test the flashlight, then the one-minute alarm.

## Next milestone
Prayer-time calculation (location/manual city), per-prayer toggles, daily rescheduling, boot rescheduling, stop/snooze UI, and robust foreground handling.

## Build APK with GitHub Actions
This project includes `.github/workflows/build-apk.yml`.
Push the project to GitHub, open **Actions**, run **Build Android APK**, then download the artifact `NoorPrayer-V0.1-debug-apk`.
