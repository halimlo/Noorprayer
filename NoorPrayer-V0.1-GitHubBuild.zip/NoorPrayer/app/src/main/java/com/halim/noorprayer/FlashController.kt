package com.halim.noorprayer

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper

class FlashController(context: Context) {
    private val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val handler = Handler(Looper.getMainLooper())
    private val cameraId: String? = cm.cameraIdList.firstOrNull { id -> cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }

    fun blink(times: Int, intervalMs: Long) {
        val id = cameraId ?: return
        var step = 0
        val task = object : Runnable {
            override fun run() {
                try { cm.setTorchMode(id, step % 2 == 0) } catch (_: Exception) {}
                step++
                if (step < times * 2) handler.postDelayed(this, intervalMs) else try { cm.setTorchMode(id, false) } catch (_: Exception) {}
            }
        }
        handler.post(task)
    }
}
