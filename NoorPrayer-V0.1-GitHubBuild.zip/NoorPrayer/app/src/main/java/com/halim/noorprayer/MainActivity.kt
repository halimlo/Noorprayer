package com.halim.noorprayer

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)

        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(40,60,40,40) }
        val title = TextView(this).apply { text="نور الصلاة"; textSize=30f; gravity=Gravity.CENTER }
        val info = TextView(this).apply { text="منبّه ضوئي + مواقيت الصلاة\n\nV0.1: اختبر الفلاش ثم أضف منبهاً تجريبياً بعد دقيقة."; textSize=18f; gravity=Gravity.CENTER }
        val test = Button(this).apply { text="اختبار الفلاش"; setOnClickListener { FlashController(this@MainActivity).blink(10, 300) } }
        val alarm = Button(this).apply { text="منبه بعد دقيقة"; setOnClickListener { scheduleOneMinute(); Toast.makeText(this@MainActivity,"تم ضبط المنبه",Toast.LENGTH_SHORT).show() } }
        val permission = Button(this).apply { text="السماح بالمنبهات الدقيقة"; setOnClickListener { requestExactAlarmAccess() } }
        listOf(title,info,test,alarm,permission).forEach { box.addView(it, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,18,0,18) }) }
        setContentView(box)
    }

    private fun requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
    }

    private fun scheduleOneMinute() {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) { requestExactAlarmAccess(); return }
        val pi = PendingIntent.getBroadcast(this, 100, Intent(this, AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+60_000, pi)
    }
}
